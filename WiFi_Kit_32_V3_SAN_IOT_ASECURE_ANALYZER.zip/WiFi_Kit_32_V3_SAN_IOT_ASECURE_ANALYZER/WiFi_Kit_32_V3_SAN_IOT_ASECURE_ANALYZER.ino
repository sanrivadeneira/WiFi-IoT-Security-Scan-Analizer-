#include "Arduino.h"

#include "WiFi.h"

#include <Wire.h>

#include "HT_SSD1306Wire.h"

#include <WebServer.h>

#include <BLEDevice.h>

#include <BLEUtils.h>

#include <BLEScan.h>

#include <BLEAdvertisedDevice.h>



#define LED_BLANCO 35

#define VEXT_PIN 36



SSD1306Wire oled(0x3c, 400000, 17, 18, GEOMETRY_128_64, 21);

WebServer server(80);



int wifiCount = 0;

int bleCount = 0;

BLEScan* pBLEScan;

String currentDataJson = ""; // Guardamos el último JSON para la descarga


const char INDEX_HTML[] PROGMEM = R"=====(

<!DOCTYPE html>

<html>

<head>

    <meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1">

    <title>WiFi IoT  Security Scan Analizer by RIKRSA v0m2026Hub</title>

    <style>

        body { font-family: 'Segoe UI', sans-serif; background: #0f172a; color: #f8fafc; margin: 0; padding: 20px; }

        .container { max-width: 1200px; margin: auto; }

        .header-flex { display: flex; justify-content: space-between; align-items: center; margin-bottom: 20px; }

        h1 { color: #38bdf8; margin: 0; text-transform: uppercase; font-size: 1.5em; }

        .btn-download { background: #10b981; color: white; border: none; padding: 10px 20px; border-radius: 6px; cursor: pointer; font-weight: bold; transition: 0.3s; }

        .btn-download:hover { background: #059669; }

        .grid { display: grid; grid-template-columns: 1.2fr 1fr; gap: 20px; }

        .card { background: #1e293b; padding: 20px; border-radius: 12px; border: 1px solid #334155; height: 500px; overflow-y: auto; }

        table { width: 100%; border-collapse: collapse; }

        th { text-align: left; color: #38bdf8; padding: 10px; border-bottom: 2px solid #334155; position: sticky; top: 0; background: #1e293b; }

        td { padding: 10px; border-bottom: 1px solid #334155; font-size: 0.85em; }

        .stat-bar { background: #38bdf8; color: #0f172a; padding: 12px; font-weight: bold; margin-bottom: 20px; border-radius: 8px; display: flex; justify-content: space-around; }

        .good { color: #4ade80; } .mid { color: #fbbf24; } .bad { color: #f87171; }

    </style>

</head>

<body>

    <div class="container">

        <div class="header-flex">

            <h1>WiFi IoT  Security Scan Analizer by RICKRSA v0m2026 Dashboard</h1>

            <button class="btn-download" onclick="downloadCSV()">⬇ DESCARGAR CSV</button>

        </div>

        <div class="stat-bar">

            <span id="ip-display">CONECTANDO...</span>

            <span id="wifi-total">WIFI: 0</span>

            <span id="ble-total">BLE: 0</span>

        </div>

        <div class="grid">

            <div class="card">

                <h2>Infraestructura WiFi</h2>

                <table id="wifi-table-data">

                    <thead><tr><th>SSID</th><th>CH</th><th>RSSI</th><th>Calidad</th></tr></thead>

                    <tbody id="wifi-table"></tbody>

                </table>

            </div>

            <div class="card">

                <h2>Dispositivos IoT (BLE)</h2>

                <table id="ble-table-data">

                    <thead><tr><th>Dirección MAC</th><th>Señal</th></tr></thead>

                    <tbody id="ble-table"></tbody>

                </table>

            </div>

        </div>

    </div>

    <script>

        let lastReceivedData = null;



        function update() {

            fetch('/data').then(res => res.json()).then(data => {

                lastReceivedData = data;

                document.getElementById('ip-display').innerText = "IP: " + data.ip;

                document.getElementById('wifi-total').innerText = "WIFI DETECTADOS: " + data.wifi_c;

                document.getElementById('ble-total').innerText = "BLE DETECTADOS: " + data.ble_c;

                

                let wHtml = "";

                data.wifi_list.forEach(n => {

                    let cl = n.r > -60 ? "good" : (n.r > -80 ? "mid" : "bad");

                    wHtml += `<tr><td><strong>${n.s}</strong></td><td>${n.c}</td><td>${n.r} dBm</td><td class="${cl}">${n.q}</td></tr>`;

                });

                document.getElementById('wifi-table').innerHTML = wHtml;



                let bHtml = "";

                data.ble_list.forEach(b => {

                    bHtml += `<tr><td>${b.m}</td><td class="good">${b.r} dBm</td></tr>`;

                });

                document.getElementById('ble-table').innerHTML = bHtml;

            });

        }



        function downloadCSV() {

            if(!lastReceivedData) return;

            let csv = "TIPO,IDENTIFICADOR,CANAL,RSSI,CALIDAD\n";

            lastReceivedData.wifi_list.forEach(n => {

                csv += `WIFI,${n.s},${n.c},${n.r},${n.q}\n`;

            });

            lastReceivedData.ble_list.forEach(b => {

                csv += `BLE,${b.m},-,${b.r},Detectado\n`;

            });

            

            let blob = new Blob([csv], { type: 'text/csv' });

            let url = window.URL.createObjectURL(blob);

            let a = document.createElement('a');

            a.setAttribute('hidden', '');

            a.setAttribute('href', url);

            a.setAttribute('download', 'reporte_iot_rickrsa.csv');

            document.body.appendChild(a);

            a.click();

            document.body.removeChild(a);

        }



        setInterval(update, 5000);

        update();

    </script>

</body>

</html>

)=====";



void handleData() {

  wifiCount = WiFi.scanNetworks();

  BLEScanResults* foundDevices = pBLEScan->start(2, false); 

  bleCount = foundDevices->getCount();



  Serial.println("\n[SISTEMA RICKRSA] Generando reporte...");

  

  String json = "{";

  json += "\"ip\":\"" + WiFi.localIP().toString() + "\",";

  json += "\"wifi_c\":" + String(wifiCount) + ",";

  json += "\"ble_c\":" + String(bleCount) + ",";

  

  json += "\"wifi_list\":[";

  for (int i = 0; i < wifiCount; i++) {

    int rssi = WiFi.RSSI(i);

    int ch = WiFi.channel(i);

    String q = (rssi > -60) ? "Excelente" : (rssi > -80 ? "Fuerte" : "Debil");

    Serial.printf("WIFI | %-20s | CH: %02d | %d dBm\n", WiFi.SSID(i).c_str(), ch, rssi);

    json += "{\"s\":\"" + WiFi.SSID(i) + "\",\"c\":" + String(ch) + ",\"r\":" + String(rssi) + ",\"q\":\"" + q + "\"}";

    if (i < wifiCount - 1) json += ",";

  }

  json += "],";



  json += "\"ble_list\":[";

  for (int i = 0; i < bleCount; i++) {

    BLEAdvertisedDevice device = foundDevices->getDevice(i);

    String mac = device.getAddress().toString().c_str();

    int r = device.getRSSI();

    Serial.printf("BLE  | %-20s | RSSI: %d dBm\n", mac.c_str(), r);

    json += "{\"m\":\"" + mac + "\",\"r\":" + String(r) + "}";

    if (i < bleCount - 1) json += ",";

  }

  json += "]}";



  pBLEScan->clearResults(); 

  server.send(200, "application/json", json);

}



void handleRoot() { server.send(200, "text/html", INDEX_HTML); }



void setup() {

  pinMode(VEXT_PIN, OUTPUT); digitalWrite(VEXT_PIN, LOW); 

  pinMode(LED_BLANCO, OUTPUT); digitalWrite(LED_BLANCO, LOW);

  Serial.begin(115200);

  oled.init(); oled.flipScreenVertically();

  

  BLEDevice::init("");

  pBLEScan = BLEDevice::getScan();

  pBLEScan->setActiveScan(true);



  WiFi.mode(WIFI_STA);

  WiFi.begin("NOMBRE DE LA RED", "PASSWORD");

  while (WiFi.status() != WL_CONNECTED) { delay(500); Serial.print("."); }



  digitalWrite(LED_BLANCO, HIGH);

  server.on("/", handleRoot);

  server.on("/data", handleData);

  server.begin();

  Serial.println("\n[SISTEMA OK]");

}



void loop() {

  server.handleClient();

  static unsigned long lastOLED = 0;

  if(millis() - lastOLED > 4000) {

    lastOLED = millis();

    oled.clear();

    oled.drawRect(0, 0, 128, 30);

    oled.drawString(5, 2, "WiFi: " + String(wifiCount));

    oled.drawString(5, 15, WiFi.localIP().toString());

    oled.drawRect(0, 32, 128, 30);

    oled.drawString(5, 34, "BLE Scanned: " + String(bleCount));

    oled.display();

  }

} 